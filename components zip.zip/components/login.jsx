import React, { Component } from 'react';

class LogIn extends Component {
    state = {  }
    render() { 
        return (
            <div></div>
          );
    }
}
 
export default LogIn;