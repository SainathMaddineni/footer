import React, { Component } from 'react';

class AboutUs extends Component {
    state = {  }
    render() { 
        return ( 
            <div>
                <h1>About us</h1>
            </div>
         );
    }
}
 
export default AboutUs;