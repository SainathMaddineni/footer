import React, { Component } from 'react';

class ContactUs extends Component {
    state = {  }
    render() { 
        return ( 
            <div></div>
         );
    }
}
 
export default ContactUs;