import React, { Component } from 'react';
import {Link,BrowserRouter as Router} from 'react-router-dom';

class NavBar extends Component {
    state = {  }
    render() { 
        return ( 
            <div>
                <Router>
                    <header>
                        <div className ="container">
                            <div id="branding">
                                <h1><span className ="highlight">Slope</span>RateTech</h1>
                            </div>
                        <nav>
                            <ul>
                                <Link to = "/signup">SIGNUP</Link>
                                <Link to = "/login">LOGIN</Link>
                                <Link to = "/contact us">CONTACT US</Link>
                                <Link to = "/aboutus">ABOUT US</Link>
                                <Link to = "/services">SERVICES</Link>
                                <Link to = "/home" className = "current"><a>HOME</a></Link>
                            </ul>
                        </nav>
                        </div>
                    </header>
                </Router>
            </div>
         );
    }
}
 
export default NavBar;
