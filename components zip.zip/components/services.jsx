import React, { Component } from 'react';

class Services extends Component {
    state = {  }
    render() { 
        return ( 
            <div></div>
         );
    }
}
 
export default Services;