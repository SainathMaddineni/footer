import React, { Component } from 'react';

class Footer extends Component {
    state = {  }
    render() { 
        return ( 
            <div>
                <footer>
                    <p>SlopeRateTech,Copyright&copy;2020</p>
                </footer>
            </div>
         );
    }
}
 
export default Footer;